# **Lab 04**

## Le cours
Premièrement, c'est un cours assez spécial à cause du professeur. La gestion de classe est complètement inexistante. Le cours est *utile* au moins, il laisse du temps pour faire les travaux des autres cours et pour apprendre à connaître les autres élèves. 

### `Les logiciels`
Deuxièmement, on a appris à utiliser les styles sur Microsoft Word et comment utiliser One Drive. 
Le Markdown semble intéressant et facile à utiliser grâce à Visual Studio Code. Pour le moment, on connait seulement la base, comment mettre un titre, mettre en gras, ajouter un lien, une image, etc.

#### ***Mon niveau de confort***
Finalement, mon niveau de confort est bas parce que je ne sais pas à quoi m'attendre avec un prof qui improvise sans arrêt et qui passe la moitié du cours sur des sujets qui n'ont rien à avoir avec l'informatique. Au moins, c'est divertissant. 

